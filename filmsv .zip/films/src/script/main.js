document.addEventListener('DOMContentLoaded', function() {
  var logado = localStorage.getItem('logado');
  
  if (logado === 'sim') {
    // Exibir botão quando estiver logado
    var botaoNaoLogadoLogin = document.querySelector('#nao_logado_login');
    var botaoNaoLogadoCadastro = document.querySelector('#nao_logado_cadastro');
    var botaoLogado = document.querySelector('#logado');

    botaoNaoLogadoLogin.style.display = 'none';
    botaoNaoLogadoCadastro.style.display = 'none';
    botaoLogado.style.display = 'block';

  } else {
    // Exibir outro botão quando não estiver logado
    botaoNaoLogadoLogin.style.display = 'block';
    botaoNaoLogadoCadastro.style.display = 'block';
  }
});

// Animação de scroll para uma interface e experiência do usuário melhor

let lastScroll = 0;

document.addEventListener("scroll", function () {
    const header = document.querySelector("header");
    const currentScroll = window.scrollY;
    if (currentScroll > lastScroll && header.classList.contains("fadeDown")) {
        header.classList.remove("fadeDown")
        header.classList.add("fadeUp")
    } else if (currentScroll < lastScroll && header.classList.contains("fadeUp")) {
        header.classList.remove("fadeUp")
        header.classList.add("fadeDown")
    }
    lastScroll = currentScroll;
})

document.querySelector('.registrar-usuario').addEventListener('click', function(e) {

    // capturar elementos do form
    let formContent = [];

    let nome = document.querySelector('#nome').value
    let sobrenome = document.querySelector('#sobrenome').value
    let celular = document.querySelector('#celular').value
    let email = document.querySelector('#email').value
    let senha = document.querySelector('#senha').value

    // Se algum campo estiver vazio disparar alerta em tela
    if(nome == '' || sobrenome == '' || celular == '' || email == '' || senha == '') {

        alert('Preencha todos os campos para prosseguir');
        return;
    } else{
        alert('Usuário cadastrado com sucesso');
    }

    formContent.push(nome, sobrenome, celular, email, senha)

    // Colocando o formContent no localStorage
    // Convertendo o array em uma string JSON
    let formContentString = JSON.stringify(formContent);

    // Gerando uma chave única
    let chaveUnica = 'chave_' + Date.now();

    // Armazenando a string no localStorage com a chave única
    if(formContentString) {

        localStorage.setItem(chaveUnica, formContentString);
    }

    window.location.reload();
})

document.querySelector('#entrar').addEventListener('click', function(e) {

    let emailLogin = document.querySelector('#email_login').value;
    let senhaLogin = document.querySelector('#senha_login').value;
    let loginSucesso = false;

    console.log(emailLogin, senhaLogin);

    // Mesmo esquema de registro, se estiver vazio não prosseguir com o script
    if(emailLogin == '' || senhaLogin == '') {

        alert('Preencha todos os campos para fazer o login');
        return;
    }

    // Percorrendo todas as chaves do localStorage
    for (var i = 0; i < localStorage.length; i++) {
        var chave = localStorage.key(i);
    
        // Verificando se a chave começa com "chave_" (chaves geradas anteriormente)
        if (chave.startsWith('chave_')) {
        var formContentString = localStorage.getItem(chave);
        var formContent = JSON.parse(formContentString);
    
        console.log(formContent[3], nome, formContent[4])
        // Comparando nome e senha com os valores armazenados
        if (formContent[3] === emailLogin && formContent[4] === senhaLogin) {
            
            loginSucesso = true;
            alert('Login realizado com sucesso');
            break; // Encerrando o loop, pois encontrou uma correspondência
        }
        }
    }
    
    // Se o loop terminar sem encontrar uma correspondência, exibir mensagem de credenciais inválidas
    if (i === localStorage.length) {
        alert('As credenciais não existem.');
    }

    // Se o login for bem-sucedido, registrar no localStorage como 'logado: sim'
    if (loginSucesso) {
        localStorage.setItem('logado', 'sim');
    } else {
        localStorage.setItem('logado', 'nao');
    }

    window.location.reload();
})

// Deslogar
document.querySelector('#logado').addEventListener('click', function(e) {

    localStorage.setItem('logado', 'não');
    window.location.reload();
})
